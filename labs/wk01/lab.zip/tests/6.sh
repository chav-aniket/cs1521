"./$1" < tests/6.txt
