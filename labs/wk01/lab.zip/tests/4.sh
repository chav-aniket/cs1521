"./$1" < tests/4.txt
